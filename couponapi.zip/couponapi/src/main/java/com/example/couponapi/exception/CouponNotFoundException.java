package com.example.couponapi.exception;




public class CouponNotFoundException extends RuntimeException {

	public CouponNotFoundException(String message) {
		super(message);
		
	}

	
	
}
