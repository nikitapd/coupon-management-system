package com.example.couponapi.exception;

public class InvalidCouponException extends RuntimeException {

	public InvalidCouponException(String message) {
		super(message);
		
	}
	
	

}
