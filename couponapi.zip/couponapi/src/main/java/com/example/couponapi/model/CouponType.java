package com.example.couponapi.model;

             //*****enum*********
 
public enum CouponType {
	
	CART_WISE,
    PRODUCT_WISE,
    BXYG


}
