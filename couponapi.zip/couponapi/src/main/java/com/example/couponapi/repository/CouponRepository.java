package com.example.couponapi.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.couponapi.model.Coupon;



public interface CouponRepository extends JpaRepository<Coupon, Long> {

}
