package com.example.couponapi.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Coupon {

        @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long id;

        private String type; // cart-wise, product-wise, bxgy

	    @Column(columnDefinition = "TEXT")
	    private String details; // JSON String for details

		public Coupon() {
			
		}

		public Coupon(Long id, String type, String details) {
			super();
			this.id = id;
			this.type = type;
			this.details = details;
		}

		public Long getId() {
			return id;
		}

		public void setId(Long id) {
			this.id = id;
		}

		public String getType() {
			return type;
		}

		public void setType(String type) {
			this.type = type;
		}

		public String getDetails() {
			return details;
		}

		public void setDetails(String details) {
			this.details = details;
		}

		@Override
		public String toString() {
			return "Coupon [id=" + id + ", type=" + type + ", details=" + details + "]";
		}


	    
	    
	    
	    
}
