package com.example.couponapi.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.example.couponapi.model.Coupon;
import com.example.couponapi.repository.CouponRepository;

public class CouponServiceTest {
	
	
	 @Mock
	 private CouponRepository couponRepository;

	 @InjectMocks
	 private CouponService couponService;
	 
	 @BeforeEach
	    public void setUp() {
	        MockitoAnnotations.openMocks(this);
	    }

	 @Test
	    public void testCreateCoupon() {
	        Coupon coupon = new Coupon();
	        coupon.setType("cart-wise");
	        coupon.setDetails("{\"threshold\": 100, \"discount\": 10}");

	        when(couponRepository.save(coupon)).thenReturn(coupon);

	        Coupon createdCoupon = couponService.createCoupon(coupon);
	        assertNotNull(createdCoupon);
	        assertEquals("cart-wise", createdCoupon.getType());
	    }

	    @Test
	    public void testGetAllCoupons() {
	        Coupon coupon1 = new Coupon();
	        coupon1.setType("cart-wise");

	        Coupon coupon2 = new Coupon();
	        coupon2.setType("product-wise");

	        when(couponRepository.findAll()).thenReturn(Arrays.asList(coupon1, coupon2));

	        List<Coupon> coupons = couponService.getAllCoupons();
	        assertEquals(2, coupons.size());
	    }

	 


}
